import{b as p,E as t}from"./DEYVqDYQ.js";import{B as c}from"./Cc4zGfaP.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
