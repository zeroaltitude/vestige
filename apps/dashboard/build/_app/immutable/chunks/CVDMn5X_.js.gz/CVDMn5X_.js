import{b as p,E as t}from"./DleE0ac1.js";import{B as c}from"./BolYP48w.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
